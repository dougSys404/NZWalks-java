package br.doug.NZWalks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NzWalksApplicationTests {

	@Test
	void contextLoads() {
	}

}
