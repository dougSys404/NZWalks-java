package br.doug.NZWalks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NzWalksApplication {

	public static void main(String[] args) {
		SpringApplication.run(NzWalksApplication.class, args);
	}

}
